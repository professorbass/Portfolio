/**
 * Demonstarting Porus Defenses
 * Abass Kanu
 * 04/27/21
 * purpose: To implement a bank account
 * 
 */
 package bankaccount;
 import java.util.Scanner       // Needed for the scanner class
 
 public class Account
 {
     @suppressWarnings ("null")
     public static void main (String[] args)
     {
         
         BankAccount account = null; // BankAccount object
         double balance,    // The account's starting balance
         pay,   //The User's pay
         cash;  //
            cash = 0;
            
            // Create a Scanner object for keyboard input.
            Scanner keyboard = new Scanner(System.in);
            
            //Account name
            System.out.print("Johnny's Checking Account"+"\r\n" );
            
            //Get the starting balance 
            System.out.print("Your account's"+"starting balance is:");
            balance = keyboard.nextdouble();
            
            // Get bankaccount object
            account = new BankAccount (balance);
            
            // Get the amount direct deposited in account for the month.
            
            System.out.print("What was direct deposited in your account this month?");
            pay = keyboard.next.Double(700);
            
            //Withdrawl from the account
            System.out.print("How would you like"+"to withdraw? ");
            cash = keyboard.nextDouble ();
            account.withdraw(cash);
            
            
            //Withdrawl from the account
            System.out.print("Your current balance is "+""+ (account.getbalance()));
            
     }
 }
 