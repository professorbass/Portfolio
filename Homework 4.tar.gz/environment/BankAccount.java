/**
 * Demonstarting Porus Defenses
 * Abass Kanu
 * 04/27/21
 * purpose: To implement a bank account
 * 
 */
 package bankaccount;
 
public class BankAccount {
	private double balance; // Account Balance
	private double deposit; //Account deposit
	public int withdrawlcount = 0;
	
	public BankAccount (double startbalance) {
		balance = startbalance;
	}
	// Money deposited will be added to the balance
	public void deposit(double amount)
	{
		balance += amount;
	}
	
	// Money will be subtracted from the balance
		public void withdraw (double amount)
		{
		balance -= amount
		withdrawlcount++;
		
	
	}
	public double getBalance()
	{
		return balance;
	}
	
}