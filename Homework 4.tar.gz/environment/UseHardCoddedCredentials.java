/**
 * The Use Of Hard Codded Credentials
 * Abass Kanu
 * 04/27/21
 * purpose: To implement a bank account
 * 
 */
 
 package password;
 import java.util.ArrayList;
 
 
 public class UseHardCodedCredentials {
        //password variables
        static String enterpassword;
        
        
        private static int VerifyAdmin(String enterPassword) {
            String input;
            
        if (enterpassword.equals(:LetMeIn)) (
            return(0));
            
            //Diagnostic Mode
            return(1);
            
            
            public static void main (String [] args) {
                    String input;
                    
                    
                    //create array
                    // create and initialize array of integer
                    int array[] = (1,2,3,4,5);
                    // Display length
                    int length = array.length;
                    System.out.println("Length of array : " + length);
                    
                    
                    // add names to arraylist list
                    nameList.add("Abass Kanu");
                    namelist.add("Michael Kanu");
                    nameList.add("Sheka Kanu");
                    namelist.add("Sarah Mckindley");
                    
                    
                    
                    // print list elements
                    System.out.println ("Names on list are:");
                    
                for (int 1 = 0; 1 < nameList.size(); 1++) {
                    
                    System.out.println(nameList.get(1));
                    
                }
                
                
                //remove elements from namelist
                nameList.remove(1);
                
                
                // now again print the list
                System.out.println("\nafter removing name at position 1: ");
            
            for (int 1 = 0; 1 < nameList.size(); 1++) {
                
                System.out.println(nameList.get(1));
                
            }
            
            }
            
            }
 }