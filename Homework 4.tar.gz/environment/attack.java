/**
 * An Attack That Uses  Hard Codded Credentials
 * Abass Kanu
 * 04/27/21
 * purpose: An attacker gain access to the program
 * 
 */
 
 import java.util.ArrayList;
 
 public class Attack {
 //password variables
    static String enter password
    
    private static int VerifyAdmin(String enter password) {
        String input;
        
    if (enterpassword.equals("LetMeIn)){
    return(0);
    }
    
    //Diagnostic mode
    return(1);
    
}
    
        public static void main (String [] args) {
        String input;
        
        
        //create array//create and initialize array of integer
        int array [] = (1,2,3,4,5);
        // Display length
        int legnth = array.length;
        
        System.out.println("Length of array : " + length);
        
        // create Arraylist
        ArrayList <String> nameList = new ArrayList <>();
        
        
        //add names to arraylist list
        nameList.add("Abass Kanu");
        nameList.add("Michael Kanu");
        nameList.add("Timmy Turner");
        nameList.add("Rodney Rankin");