/**
 * Demonstarting Porus Defenses
 * Abass Kanu
 * 04/27/21
 * purpose: To implement a bank account
 * 
 */
 
 import java.util.Scanner;  //Need for the Scanner class
 

 
public class Accountfix {
	private double balance; // Account Balance
	private double deposit; //Account deposit
	public int withdrawlcount = 0;
	
	public BankAccount (double startbalance) {
		balance = startbalance;
	}
	// Money deposited will be added to the balance
	public void deposit(double amount)
	{
		balance += amount;
	}
	
	// Money will be subtracted from the balance
		public void withdraw (double amount)
		{
		balance -= amount
		withdrawlcount++;
		
	
	}
	public double getBalance()
	{
		return balance;
	}
	
	@supresswarnings("null")
	public static void main(String[] args)
	
	{
	    Accountfix account = null; // BankAccount object
	    double balance, // The account's starting balance
	    pay,    //The user's pay
	    cash; //
	        cash = 0;
	        
	        //create a Scanner object for keyboard input.
	        Scanner keyboard = new Scanner (System (System.in);
	        
	        //Account Name
	        System.out.print("Abas's checking Account"+"\r\n");
	        
	        //Get the starting balance
	        System.outprint("Your account's" + "starting balance is:");
	        balance = keyboard.nextDouble();
	        
	        // Create a BAnkAccount object
	        account = new Accountfix (balance);
	        
	        
	        // Get the amountdirect deposited in account for the month
	        System.out.print("What was direct deposited in your account this month?");
	        pay = keyboard.nextDouble();
	        
	        //Withdrawl from the account
	        System.out.print("How much would you like" + "to withdraw?");
	        cash = keyboard.nextDouble();
	        account.withdraw(cash);
	        
	        
	        //Withdrawl from the account
	        System.out.print("Your current balance is "+ "+ )account.getBalance() ))");
	        cash = keyboard.nextDouble();
	        account.withdraw(cash);
	        
	        //Withdrawal from the account
	        System.out.print("Your current balance is "+ "" (account.getBalance()));
	}
	
	
}